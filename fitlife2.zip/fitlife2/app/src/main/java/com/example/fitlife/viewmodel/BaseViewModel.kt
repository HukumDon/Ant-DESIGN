package com.example.fitlife.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fitlife.data.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Base ViewModel that provides common functionality for all ViewModels.
 */
abstract class BaseViewModel<ViewState, ViewEvent> : ViewModel() {
    protected val _viewState = MutableStateFlow<ViewState?>(null)
    val viewState: StateFlow<ViewState?> = _viewState

    protected val _event = MutableStateFlow<ViewEvent?>(null)
    val event: StateFlow<ViewEvent?> = _event

    protected val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    protected val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    protected fun <T> handleResult(
        result: Result<T>,
        onSuccess: (T) -> Unit = {},
        onError: ((Exception) -> Unit)? = null
    ) {
        viewModelScope.launch {
            _isLoading.value = false
            when (result) {
                is Result.Success -> {
                    _error.value = null
                    onSuccess(result.data)
                }
                is Result.Error -> {
                    _error.value = result.exception.message
                    onError?.invoke(result.exception)
                }
            }
        }
    }

    protected fun setLoading(isLoading: Boolean) {
        _isLoading.value = isLoading
    }

    protected fun setError(message: String?) {
        _error.value = message
    }

    protected fun sendEvent(event: ViewEvent) {
        _event.value = event
    }

    fun consumeEvent() {
        _event.value = null
    }
}
