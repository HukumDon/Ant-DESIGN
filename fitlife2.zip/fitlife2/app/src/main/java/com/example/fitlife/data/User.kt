package com.example.fitlife.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Data class representing a User in the application.
 * @property id Unique identifier for the user (auto-generated)
 * @property username Unique username for the user
 * @property email User's email address
 * @property password User's hashed password (should be hashed before storing)
 * @property createdAt Timestamp when the user was created
 */
@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    val email: String,
    val password: String,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        // Default user for testing/demo purposes
        val DEFAULT_USERS = listOf(
            User(
                username = "user1",
                email = "user1@example.com",
                password = "password123" // In a real app, this should be hashed
            ),
            User(
                username = "user2",
                email = "user2@example.com",
                password = "password123"
            )
        )
    }
}
