package com.example.fitlife.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fitlife.data.Exercise
import com.example.fitlife.data.Result
import com.example.fitlife.data.repository.ExerciseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI state for Exercise screen
 */
data class ExerciseUiState(
    val exercises: List<Exercise> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val searchQuery: String = "",
    val showCompleted: Boolean = false
)

/**
 * Events that can be triggered from the Exercise screen
 */
sealed class ExerciseEvent {
    data class ShowMessage(val message: String) : ExerciseEvent()
    data class NavigateToExerciseDetail(val exerciseId: Long) : ExerciseEvent()
    object NavigateToAddExercise : ExerciseEvent()
}

/**
 * ViewModel for managing exercise-related UI state and logic
 */
@HiltViewModel
class ExerciseViewModel @Inject constructor(
    private val exerciseRepository: ExerciseRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExerciseUiState())
    val uiState: StateFlow<ExerciseUiState> = _uiState.asStateFlow()

    private val _event = MutableStateFlow<ExerciseEvent?>(null)
    val event: StateFlow<ExerciseEvent?> = _event.asStateFlow()

    private var currentUserId: Long = 0L

    /**
     * Initializes the ViewModel with the current user ID
     */
    fun initialize(userId: Long) {
        currentUserId = userId
        loadExercises()
    }

    /**
     * Loads exercises for the current user
     */
    private fun loadExercises() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                val exercises = if (_uiState.value.showCompleted) {
                    exerciseRepository.getCompletedExercises(currentUserId)
                } else {
                    exerciseRepository.getIncompleteExercises(currentUserId)
                }
                
                exercises.collectLatest { exerciseList ->
                    _uiState.value = _uiState.value.copy(
                        exercises = exerciseList,
                        isLoading = false,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Failed to load exercises"
                )
            }
        }
    }

    /**
     * Toggles the completion status of an exercise
     */
    fun toggleExerciseCompletion(exercise: Exercise) {
        viewModelScope.launch {
            val result = exerciseRepository.toggleExerciseCompletion(
                exercise.id,
                !exercise.isCompleted
            )
            
            if (result is Result.Success) {
                loadExercises() // Refresh the list
            } else {
                _event.value = ExerciseEvent.ShowMessage(
                    (result as? Result.Error)?.exception?.message ?: "Failed to update exercise"
                )
            }
        }
    }

    /**
     * Deletes an exercise
     */
    fun deleteExercise(exercise: Exercise) {
        viewModelScope.launch {
            val result = exerciseRepository.deleteExercise(exercise)
            if (result is Result.Success) {
                loadExercises() // Refresh the list
                _event.value = ExerciseEvent.ShowMessage("Exercise deleted")
            } else {
                _event.value = ExerciseEvent.ShowMessage(
                    (result as? Result.Error)?.exception?.message ?: "Failed to delete exercise"
                )
            }
        }
    }

    /**
     * Handles search query changes
     */
    fun onSearchQueryChanged(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        if (query.isNotEmpty()) {
            searchExercises(query)
        } else {
            loadExercises()
        }
    }

    /**
     * Searches exercises by name
     */
    private fun searchExercises(query: String) {
        viewModelScope.launch {
            try {
                exerciseRepository.searchExercises(query, currentUserId)
                    .collect { exercises ->
                        _uiState.value = _uiState.value.copy(
                            exercises = exercises,
                            error = null
                        )
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = e.message ?: "Search failed"
                )
            }
        }
    }

    /**
     * Toggles between showing completed and incomplete exercises
     */
    fun toggleShowCompleted() {
        _uiState.value = _uiState.value.copy(
            showCompleted = !_uiState.value.showCompleted
        )
        loadExercises()
    }

    /**
     * Handles navigation to exercise details
     */
    fun onExerciseClick(exercise: Exercise) {
        _event.value = ExerciseEvent.NavigateToExerciseDetail(exercise.id)
    }

    /**
     * Handles the FAB click to add a new exercise
     */
    fun onAddExerciseClick() {
        _event.value = ExerciseEvent.NavigateToAddExercise
    }

    /**
     * Consumes the current event
     */
    fun onEventConsumed() {
        _event.value = null
    }

    /**
     * Clears the current error
     */
    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}
