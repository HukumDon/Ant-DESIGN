package com.example.fitlife.data.repository

import com.example.fitlife.data.Result
import com.example.fitlife.data.User
import com.example.fitlife.data.UserDao
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * Repository for handling user data operations.
 */
class UserRepository @Inject constructor(
    private val userDao: UserDao
) : BaseRepository() {

    /**
     * Registers a new user.
     */
    suspend fun registerUser(username: String, email: String, password: String): Result<Long> {
        return safeApiCall {
            // Check if username or email already exists
            if (userDao.getUserByUsername(username) != null) {
                throw Exception("Username already exists")
            }
            if (userDao.getUserByEmail(email) != null) {
                throw Exception("Email already registered")
            }
            
            // Create and insert new user
            val user = User(
                username = username,
                email = email,
                password = password // In a real app, this should be hashed
            )
            userDao.insertUser(user)
        }
    }

    /**
     * Authenticates a user.
     */
    suspend fun login(username: String, password: String): Result<User> {
        return safeApiCall {
            userDao.login(username, password) ?: throw Exception("Invalid username or password")
        }
    }

    /**
     * Gets a user by ID.
     */
    fun getUserById(userId: Long): Flow<User?> {
        return userDao.getUserById(userId).flowOnIO()
    }

    /**
     * Updates user information.
     */
    suspend fun updateUser(user: User): Result<Unit> {
        return safeApiCall {
            userDao.updateUser(user)
        }
    }

    /**
     * Deletes a user.
     */
    suspend fun deleteUser(user: User): Result<Unit> {
        return safeApiCall {
            userDao.deleteUser(user)
        }
    }

    /**
     * Gets all users (for admin purposes).
     */
    fun getAllUsers(): Flow<List<User>> {
        return userDao.getAllUsers().flowOnIO()
    }
}
