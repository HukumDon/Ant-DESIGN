package com.example.fitlife.data

import androidx.lifecycle.LiveData
import androidx.room.*

/**
 * Data Access Object for the Workout entity.
 * Provides methods to perform database operations on the workouts table.
 */
@Dao
interface WorkoutDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkout(workout: Workout): Long

    @Update
    suspend fun updateWorkout(workout: Workout)

    @Delete
    suspend fun deleteWorkout(workout: Workout)

    @Query("SELECT * FROM workouts WHERE id = :workoutId")
    suspend fun getWorkoutById(workoutId: Long): Workout?

    @Query("SELECT * FROM workouts WHERE userId = :userId ORDER BY title ASC")
    fun getAllWorkoutsByUser(userId: Long): LiveData<List<Workout>>

    @Query("SELECT * FROM workouts WHERE userId = :userId AND isCompleted = 1 ORDER BY title ASC")
    fun getCompletedWorkouts(userId: Long): LiveData<List<Workout>>

    @Query("SELECT * FROM workouts WHERE userId = :userId AND isCompleted = 0 ORDER BY title ASC")
    fun getIncompleteWorkouts(userId: Long): LiveData<List<Workout>>

    @Query("UPDATE workouts SET isCompleted = :isCompleted WHERE id = :workoutId")
    suspend fun updateWorkoutStatus(workoutId: Long, isCompleted: Boolean)

    @Query("DELETE FROM workouts WHERE userId = :userId")
    suspend fun deleteAllWorkoutsForUser(userId: Long)

    @Query("DELETE FROM workouts")
    suspend fun deleteAllWorkouts()

    @Query("SELECT * FROM workouts WHERE title LIKE '%' || :query || '%' AND userId = :userId")
    fun searchWorkouts(query: String, userId: Long): LiveData<List<Workout>>
}
