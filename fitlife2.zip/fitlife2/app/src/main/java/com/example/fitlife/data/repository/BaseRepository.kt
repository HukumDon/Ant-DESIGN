package com.example.fitlife.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn

/**
 * Base repository interface that provides common functionality for all repositories.
 */
abstract class BaseRepository {
    /**
     * Wraps a suspend function call in a coroutine context.
     */
    protected suspend fun <T> safeApiCall(
        call: suspend () -> T
    ): Result<T> {
        return try {
            Result.success(call())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Wraps a Flow to ensure it runs on the IO dispatcher.
     */
    protected fun <T> Flow<T>.flowOnIO(): Flow<T> = flowOn(Dispatchers.IO)
}
