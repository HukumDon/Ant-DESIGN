package com.example.fitlife.data.repository

import com.example.fitlife.data.Exercise
import com.example.fitlife.data.ExerciseDao
import com.example.fitlife.data.Result
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * Repository for handling exercise data operations.
 */
class ExerciseRepository @Inject constructor(
    private val exerciseDao: ExerciseDao
) : BaseRepository() {

    /**
     * Gets all exercises for a specific user.
     */
    fun getAllExercises(userId: Long): Flow<List<Exercise>> {
        return exerciseDao.getAllExercisesByUser(userId).flowOnIO()
    }

    /**
     * Gets a specific exercise by ID.
     */
    suspend fun getExerciseById(exerciseId: Long): Result<Exercise> {
        return safeApiCall {
            exerciseDao.getExerciseById(exerciseId) ?: throw Exception("Exercise not found")
        }
    }

    /**
     * Inserts a new exercise.
     */
    suspend fun insertExercise(exercise: Exercise): Result<Long> {
        return safeApiCall {
            exerciseDao.insertExercise(exercise)
        }
    }

    /**
     * Updates an existing exercise.
     */
    suspend fun updateExercise(exercise: Exercise): Result<Unit> {
        return safeApiCall {
            exerciseDao.updateExercise(exercise)
        }
    }

    /**
     * Deletes an exercise.
     */
    suspend fun deleteExercise(exercise: Exercise): Result<Unit> {
        return safeApiCall {
            exerciseDao.deleteExercise(exercise)
        }
    }

    /**
     * Toggles the completion status of an exercise.
     */
    suspend fun toggleExerciseCompletion(exerciseId: Long, isCompleted: Boolean): Result<Unit> {
        return safeApiCall {
            exerciseDao.updateExerciseStatus(exerciseId, isCompleted)
        }
    }

    /**
     * Gets all completed exercises for a user.
     */
    fun getCompletedExercises(userId: Long): Flow<List<Exercise>> {
        return exerciseDao.getCompletedExercises(userId).flowOnIO()
    }

    /**
     * Gets all incomplete exercises for a user.
     */
    fun getIncompleteExercises(userId: Long): Flow<List<Exercise>> {
        return exerciseDao.getIncompleteExercises(userId).flowOnIO()
    }

    /**
     * Searches exercises by name for a specific user.
     */
    fun searchExercises(query: String, userId: Long): Flow<List<Exercise>> {
        return exerciseDao.searchExercises(query, userId).flowOnIO()
    }
}
