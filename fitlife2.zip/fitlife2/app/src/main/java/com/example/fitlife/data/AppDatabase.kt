package com.example.fitlife.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.fitlife.util.Converters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Room database class that serves as the main access point to the app's database.
 */
@Database(
    entities = [User::class, Exercise::class, Workout::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
@Singleton
class AppDatabase @Inject constructor() : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun exerciseDao(): ExerciseDao
    abstract fun workoutDao(): WorkoutDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fitlife_database"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Pre-populate the database with default data
                        INSTANCE?.let { database ->
                            CoroutineScope(Dispatchers.IO).launch {
                                populateDatabase(
                                    database.userDao(),
                                    database.exerciseDao(),
                                    database.workoutDao()
                                )
                            }
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun populateDatabase(
            userDao: UserDao,
            exerciseDao: ExerciseDao,
            workoutDao: WorkoutDao
        ) {
            // Insert default user if none exists
            if (userDao.getUserCount() == 0) {
                User.DEFAULT_USERS.forEach { user ->
                    val userId = userDao.insertUser(user)
                    // Insert default exercises for the user
                    Exercise.getDefaultExercises(userId).forEach { exercise ->
                        exerciseDao.insertExercise(exercise.copy(userId = userId))
                    }
                    // Insert default workouts for the user
                    Workout.getDefaultWorkouts(userId).forEach { workout ->
                        workoutDao.insertWorkout(workout.copy(userId = userId))
                    }
                }
            }
        }
    }
}
