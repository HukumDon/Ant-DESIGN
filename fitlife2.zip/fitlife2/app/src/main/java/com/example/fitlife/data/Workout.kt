package com.example.fitlife.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Data class representing a Workout in the application.
 * @property id Unique identifier for the workout (auto-generated)
 * @property title Title of the workout routine
 * @property description Optional description of the workout
 * @property equipment List of required equipment (comma-separated)
 * @property instructions Step-by-step instructions for the workout
 * @property imageUri Optional URI for the workout image
 * @property isCompleted Whether the workout has been marked as completed
 * @property userId ID of the user who created this workout (foreign key)
 * @property createdAt Timestamp when the workout was created
 */
@Entity(
    tableName = "workouts",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userId")]
)
data class Workout(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val equipment: String = "",
    val instructions: String,
    val imageUri: String? = null,
    val isCompleted: Boolean = false,
    val userId: Long,
    val createdAt: Long = System.currentTimeMillis()
) {
    // Helper method to get equipment as a list
    fun getEquipmentList(): List<String> {
        return if (equipment.isBlank()) emptyList()
        else equipment.split(",").map { it.trim() }
    }

    companion object {
        // Default workouts for testing/demo purposes
        fun getDefaultWorkouts(userId: Long): List<Workout> = listOf(
            Workout(
                title = "Full Body Workout",
                description = "A complete full body workout for all fitness levels",
                equipment = "Dumbbells, Exercise mat",
                instructions = "1. Warm up for 5-10 minutes\n2. Perform 3 sets of 10-12 reps for each exercise\n3. Rest 30-60 seconds between sets\n4. Cool down and stretch",
                userId = userId
            ),
            Workout(
                title = "Upper Body Strength",
                description = "Focus on building upper body strength",
                equipment = "Dumbbells, Pull-up bar, Bench",
                instructions = "1. Warm up with arm circles and shoulder rolls\n2. Perform 4 sets of each exercise\n3. Rest 45-60 seconds between sets\n4. Focus on controlled movements",
                userId = userId
            ),
            Workout(
                title = "Core & Abs",
                description = "Target your core muscles with this workout",
                equipment = "Exercise mat",
                instructions = "1. Warm up with light cardio\n2. Perform 3 rounds of the circuit\n3. Rest 30 seconds between exercises\n4. Focus on form and controlled movements",
                userId = userId
            )
        )
    }
}
