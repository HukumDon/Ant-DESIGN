package com.example.fitlife.data

import androidx.lifecycle.LiveData
import androidx.room.*

/**
 * Data Access Object for the Exercise entity.
 * Provides methods to perform database operations on the exercises table.
 */
@Dao
interface ExerciseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercise(exercise: Exercise): Long

    @Update
    suspend fun updateExercise(exercise: Exercise)

    @Delete
    suspend fun deleteExercise(exercise: Exercise)

    @Query("SELECT * FROM exercises WHERE id = :exerciseId")
    suspend fun getExerciseById(exerciseId: Long): Exercise?

    @Query("SELECT * FROM exercises WHERE userId = :userId ORDER BY name ASC")
    fun getAllExercisesByUser(userId: Long): LiveData<List<Exercise>>

    @Query("SELECT * FROM exercises WHERE userId = :userId AND isCompleted = 1 ORDER BY name ASC")
    fun getCompletedExercises(userId: Long): LiveData<List<Exercise>>

    @Query("SELECT * FROM exercises WHERE userId = :userId AND isCompleted = 0 ORDER BY name ASC")
    fun getIncompleteExercises(userId: Long): LiveData<List<Exercise>>

    @Query("UPDATE exercises SET isCompleted = :isCompleted WHERE id = :exerciseId")
    suspend fun updateExerciseStatus(exerciseId: Long, isCompleted: Boolean)

    @Query("DELETE FROM exercises WHERE userId = :userId")
    suspend fun deleteAllExercisesForUser(userId: Long)

    @Query("DELETE FROM exercises")
    suspend fun deleteAllExercises()

    @Query("SELECT * FROM exercises WHERE name LIKE '%' || :query || '%' AND userId = :userId")
    fun searchExercises(query: String, userId: Long): LiveData<List<Exercise>>
}
