package com.example.fitlife.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Data class representing an Exercise in the application.
 * @property id Unique identifier for the exercise (auto-generated)
 * @property name Name of the exercise
 * @property sets Number of sets
 * @property reps Number of repetitions per set
 * @property instructions Detailed instructions for performing the exercise
 * @property imageUri Optional URI for the exercise image
 * @property isCompleted Whether the exercise has been marked as completed
 * @property userId ID of the user who created this exercise (foreign key)
 * @property createdAt Timestamp when the exercise was created
 */
@Entity(
    tableName = "exercises",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userId")]
)
data class Exercise(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val sets: Int,
    val reps: Int,
    val instructions: String,
    val imageUri: String? = null,
    val isCompleted: Boolean = false,
    val userId: Long,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        // Default exercises for testing/demo purposes
        fun getDefaultExercises(userId: Long): List<Exercise> = listOf(
            Exercise(
                name = "Push-ups",
                sets = 3,
                reps = 15,
                instructions = "1. Start in a plank position with hands shoulder-width apart\n2. Lower your body until your chest nearly touches the floor\n3. Push yourself back up to the starting position",
                userId = userId
            ),
            Exercise(
                name = "Squats",
                sets = 4,
                reps = 12,
                instructions = "1. Stand with feet shoulder-width apart\n2. Lower your body as if sitting in a chair\n3. Keep your back straight and knees behind toes\n4. Return to standing position",
                userId = userId
            ),
            Exercise(
                name = "Plank",
                sets = 3,
                reps = 1, // Duration will be handled separately
                instructions = "1. Start in a push-up position\n2. Lower onto your forearms\n3. Keep your body straight from head to heels\n4. Hold for 30-60 seconds",
                userId = userId
            )
        )
    }
}
